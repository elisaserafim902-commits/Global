
import React, { useState, useEffect, useCallback } from 'react';
import Layout from './components/Layout';
import ElderlyHome from './components/ElderlyHome';
import EasyOrder from './components/EasyOrder';
import FamilyDashboard from './components/FamilyDashboard';
import ProviderPanel from './components/ProviderPanel';
import ProviderOnboarding from './components/ProviderOnboarding';
import PublicAgentPanel from './components/PublicAgentPanel';
import PublicManagerDashboard from './components/PublicManagerDashboard';
import ConsentModal from './components/ConsentModal';
import DigitalTwinView from './components/DigitalTwinView';
import CrisisOverlay from './components/CrisisOverlay';
import { 
  UserRole, Order, OrderStatus, ServiceCategory, Alert, ComplexityLevel, 
  UserContext, SystemMode, CareDigitalTwin, CareScores, DisasterEvent, 
  DisasterType, EmergencyResponse, HumanitarianResponse 
} from './types';
import { MOCK_ELDERLY_USER, INITIAL_ALERTS, UI_STRINGS, PRIVACY_POLICY_URL, TERMS_URL } from './constants';
import { Heart, Globe, ShieldCheck, ChevronRight, LogOut, Waves, Wind, Mountain, Trash2, FileText, User, Radio, Volume2, FastForward, Play, Share2 } from 'lucide-react';
import { assessEmergencyRisk, assessSilentRisk } from './services/geminiService';
import { audioService } from './services/audioService';

const App: React.FC = () => {
  // Persistence logic moved to top level
  const [activeRole, setActiveRole] = useState<UserRole>(() => {
    const saved = localStorage.getItem('vitacare_pref_role');
    return (saved as UserRole) || UserRole.ELDERLY;
  });
  
  const [currentView, setCurrentView] = useState<string>(() => {
    const saved = localStorage.getItem('vitacare_pref_view');
    return saved || 'HOME';
  });

  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [isConsentOpen, setIsConsentOpen] = useState(false);
  const [hasConsented, setHasConsented] = useState(false);
  
  const [activeDisaster, setActiveDisaster] = useState<DisasterEvent | null>(null);
  const [emergencyAIResponse, setEmergencyAIResponse] = useState<EmergencyResponse | undefined>();
  const [systemMode, setSystemMode] = useState<SystemMode>(SystemMode.NORMAL);

  // Network Detection
  useEffect(() => {
    const handleOnline = () => {
      if (!activeDisaster) setSystemMode(SystemMode.NORMAL);
      else setSystemMode(SystemMode.CRISIS);
      audioService.playSuccess();
    };
    const handleOffline = () => {
      setSystemMode(SystemMode.OFFLINE);
      audioService.playEmergency();
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    if (!navigator.onLine) setSystemMode(SystemMode.OFFLINE);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [activeDisaster]);

  // Proactive Insight Simulation
  useEffect(() => {
    if (activeRole === UserRole.ELDERLY && currentView === 'HOME' && hasConsented) {
      const timer = setTimeout(async () => {
        const insight = await assessSilentRisk(ctx);
        if (insight.risk_detected) {
          setAlerts(prev => [{
            id: `insight-${Date.now()}`,
            title: `Luiza: ${insight.risk_type}`,
            message: insight.recommended_follow_up,
            type: insight.urgency_level === 'high' ? 'danger' : 'warning',
            timestamp: new Date()
          }, ...prev]);
          audioService.playNotification();
        }
      }, 30000); // Check every 30s of idle time
      return () => clearTimeout(timer);
    }
  }, [activeRole, currentView, hasConsented]);

  // User Voice Settings
  const [voiceName, setVoiceName] = useState('Kore');
  const [speechSpeed, setSpeechSpeed] = useState<'slow' | 'normal' | 'fast'>('normal');

  const [twin] = useState<CareDigitalTwin>({
    lastKnownMood: 'Happy',
    behavioralPattern: 'Stable',
    vitalThresholds: { heartRate: '72bpm', sleep: '8.2h' },
    culturalPreferences: ['Latin', 'Family focus'],
    educationLevel: 60
  });
  
  const [scores] = useState<CareScores>({
    trust: 98,
    vulnerability: 8,
    stability: 95,
    socialEngagement: 88
  });

  const ctx: UserContext = {
    language: 'pt-BR',
    country: 'Brasil',
    complexity: ComplexityLevel.BALANCED,
    lastActivity: new Date(),
    culturalTheme: 'LATIN',
    mode: systemMode,
    twin,
    scores,
    voiceName,
    speechSpeed
  };

  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'VITA-2025-001',
      category: ServiceCategory.PHARMACY,
      description: 'Vitaminas de rotina',
      status: OrderStatus.DELIVERED,
      timestamp: new Date(Date.now() - 3600000),
      patientName: 'Dona Maria',
      familyApproved: true,
      urgency: 'routine'
    }
  ]);

  useEffect(() => {
    const consent = localStorage.getItem('vitacare_consent');
    if (!consent) setIsConsentOpen(true);
    else setHasConsented(true);
  }, []);

  const handleAcceptConsent = () => {
    audioService.playSuccess();
    localStorage.setItem('vitacare_consent', 'true');
    setHasConsented(true);
    setIsConsentOpen(false);
  };

  const handleShareAlert = async (alert: Alert) => {
    audioService.playAction();
    const shareText = `⚠️ ALERTA VITACARE [${alert.title}]\n\n${alert.message}\n\nHorário: ${alert.timestamp.toLocaleTimeString()}\n— VitaCare Global Human Infrastructure`;
    
    if (navigator.share) {
      try {
        await navigator.share({ title: alert.title, text: shareText });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') console.error('Share error:', err);
      }
    } else {
      await navigator.clipboard.writeText(shareText);
      window.alert('Copiado!');
    }
  };

  const triggerOfficialSignal = async (type: DisasterType, authority: string) => {
    setSystemMode(SystemMode.CRISIS);
    audioService.playEmergency();
    
    const mockEvent: DisasterEvent = {
      type,
      severity: 'SEVERE',
      location: 'Região do Usuário',
      timestamp: new Date(),
      guidance: ["Ativando protocolos da Luiza..."],
      humanitarian_context: `Sinal verificado via ${authority}.`
    };
    setActiveDisaster(mockEvent);

    const aiResponse = await assessEmergencyRisk(mockEvent, ctx);
    setEmergencyAIResponse(aiResponse);

    setAlerts(prev => [{
      id: `signal-${Date.now()}`,
      title: `VITA-SOS: ${type}`,
      message: `Protocolo de segurança Luiza ativado.`,
      type: 'danger',
      timestamp: new Date()
    }, ...prev]);
  };

  const handleRoleChange = useCallback((role: UserRole) => {
    setActiveRole(role);
    localStorage.setItem('vitacare_pref_role', role);
    setCurrentView('HOME');
  }, []);

  const handleViewChange = useCallback((view: string) => {
    setCurrentView(view);
    localStorage.setItem('vitacare_pref_view', view);
  }, []);

  const renderView = () => {
    if (activeDisaster && activeRole === UserRole.ELDERLY) {
      return (
        <CrisisOverlay 
          disaster={activeDisaster}
          emergencyData={emergencyAIResponse}
          onCallRescue={() => alert("🚨 SOCORRO ACIONADO.")}
          onCallFamily={() => alert("📞 Conectando com família...")}
          onConfirmSafety={() => { 
            audioService.playSuccess();
            setActiveDisaster(null); 
            setEmergencyAIResponse(undefined);
            setSystemMode(SystemMode.NORMAL); 
          }}
          language={ctx.language}
          mode={systemMode}
        />
      );
    }

    const t = UI_STRINGS[ctx.language as 'pt-BR' | 'en-US'] || UI_STRINGS['en-US'];

    switch (currentView) {
      case 'HOME':
        if (activeRole === UserRole.ELDERLY) return <ElderlyHome onGoToOrder={() => handleViewChange('EASY_ORDER')} onRequestHelp={() => alert("🚨 ALERTA SOS")} unreadCount={alerts.length} userContext={ctx} />;
        if (activeRole === UserRole.FAMILY) return <FamilyDashboard orders={orders} onApprove={(id) => setOrders(p => p.map(o => o.id === id ? {...o, familyApproved: true, status: OrderStatus.PREPARING} : o))} onCancel={(id) => setOrders(p => p.filter(o => o.id !== id))} />;
        if (activeRole === UserRole.PROVIDER) return <ProviderPanel orders={orders} onUpdateStatus={(id, s) => setOrders(p => p.map(o => o.id === id ? {...o, status: s} : o))} />;
        if (activeRole === UserRole.PUBLIC_AGENT) return <PublicAgentPanel />;
        if (activeRole === UserRole.PUBLIC_MANAGER) return <PublicManagerDashboard />;
        return null;

      case 'EASY_ORDER':
        return <EasyOrder onBack={() => handleViewChange('HOME')} onOrderCreated={(o) => setOrders(p => [...p, o])} userContext={ctx} />;

      case 'ORDERS':
        return (
          <div className="space-y-12 animate-fadeIn pb-32">
             <div className="px-4">
                <h2 className="text-7xl font-black tracking-tighter text-blue-600 leading-none uppercase">Luiza AI</h2>
                <p className="text-3xl font-bold mt-4 text-gray-400">Mensagens e Proteção.</p>
             </div>
             {alerts.map(alert => (
                <div key={alert.id} className={`p-10 rounded-[60px] border-l-[24px] shadow-4xl bg-white border-2 border-gray-50 flex flex-col gap-6 transition-all ${alert.type === 'danger' ? 'border-l-red-500' : 'border-l-blue-500'}`}>
                  <div className="flex justify-between items-start">
                     <h4 className="font-black text-4xl text-gray-950 tracking-tighter leading-none">{alert.title}</h4>
                     <span className="text-xs font-black text-gray-300 uppercase">{alert.timestamp.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}</span>
                  </div>
                  <p className="text-3xl text-gray-500 font-bold leading-tight">{alert.message}</p>
                  <div className="flex justify-end gap-6 items-center">
                    <button onClick={() => handleShareAlert(alert)} className="text-blue-500 p-4"><Share2 size={48} /></button>
                    <button onClick={() => setAlerts(p => p.filter(a => a.id !== alert.id))} className="text-gray-200 p-4"><Trash2 size={48} /></button>
                  </div>
                </div>
             ))}
          </div>
        );

      case 'PROFILE':
        return (
          <div className="space-y-12 animate-fadeIn pb-32">
            <div className="flex flex-col items-center py-10">
              <div className="w-64 h-64 bg-white rounded-[90px] flex items-center justify-center text-blue-600 mb-10 border-[24px] border-blue-50 shadow-4xl relative">
                <Heart size={120} fill="currentColor" />
                <div className="absolute -bottom-4 bg-blue-600 text-white px-8 py-2 rounded-full font-black text-[10px] uppercase tracking-[0.3em]">Protegida</div>
              </div>
              <h2 className="text-7xl font-black text-gray-950 text-center uppercase tracking-tighter leading-none">Dona Maria</h2>
            </div>

            <div className="bg-white p-12 rounded-[70px] shadow-4xl space-y-10 border-4 border-gray-50">
               <h4 className="text-4xl font-black text-gray-900 uppercase tracking-tighter">Luiza: Configurações</h4>
               <div className="space-y-6">
                  <p className="text-xs font-black uppercase text-gray-400 tracking-widest">Estilo da Voz</p>
                  <div className="grid grid-cols-2 gap-4">
                     {['Kore', 'Zephyr', 'Puck', 'Charon'].map(v => (
                       <button key={v} onClick={() => setVoiceName(v)} className={`p-6 rounded-[35px] border-4 font-black uppercase tracking-tighter ${voiceName === v ? 'bg-blue-600 text-white' : 'bg-gray-50 text-gray-400'}`}>{v}</button>
                     ))}
                  </div>
               </div>
            </div>

            <div className="bg-[#111827] p-12 rounded-[70px] shadow-4xl space-y-10 border-b-[20px] border-indigo-600">
               <h4 className="text-white font-black text-3xl uppercase tracking-tighter">Vita-SOS: Simulador</h4>
               <div className="grid grid-cols-1 gap-6">
                  <button onClick={() => triggerOfficialSignal(DisasterType.TSUNAMI, 'NOAA')} className="bg-white/10 text-white p-8 rounded-[40px] font-black text-2xl flex items-center gap-6">
                    <Waves size={32} /> Tsunami
                  </button>
                  <button onClick={() => triggerOfficialSignal(DisasterType.EARTHQUAKE, 'USGS')} className="bg-white/10 text-white p-8 rounded-[40px] font-black text-2xl flex items-center gap-6">
                    <Mountain size={32} /> Terremoto
                  </button>
               </div>
            </div>

            <div className="bg-white p-10 rounded-[70px] shadow-4xl space-y-8">
               <a href={PRIVACY_POLICY_URL} target="_blank" className="flex items-center justify-between p-8 bg-gray-50 rounded-[40px] font-black text-3xl">Política de Dados <ChevronRight size={32} /></a>
               <a href={TERMS_URL} target="_blank" className="flex items-center justify-between p-8 bg-gray-50 rounded-[40px] font-black text-3xl">Termos de Uso <ChevronRight size={32} /></a>
               <button onClick={() => alert("Logout")} className="w-full text-red-500 py-10 font-black text-4xl flex items-center justify-center gap-6"><LogOut size={48} /> Sair</button>
            </div>
          </div>
        );

      case 'DASHBOARD':
        return <DigitalTwinView context={ctx} />;

      default:
        return null;
    }
  };

  return (
    <Layout 
      activeRole={activeRole} 
      onRoleChange={handleRoleChange} 
      currentView={currentView}
      onViewChange={handleViewChange}
      language={ctx.language as 'pt-BR' | 'en-US'}
      mode={systemMode}
    >
      <ConsentModal 
        isOpen={isConsentOpen} 
        onAccept={handleAcceptConsent}
        onDecline={() => setIsConsentOpen(false)}
        language={ctx.language}
      />
      {renderView()}
    </Layout>
  );
};

export default App;
