
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import ElderlyHome from './components/ElderlyHome';
import EasyOrder from './components/EasyOrder';
import FamilyDashboard from './components/FamilyDashboard';
import ProviderPanel from './components/ProviderPanel';
import ProviderOnboarding from './components/ProviderOnboarding';
import PublicAgentPanel from './components/PublicAgentPanel';
import PublicManagerDashboard from './components/PublicManagerDashboard';
import ConsentModal from './components/ConsentModal';
import DigitalTwinView from './components/DigitalTwinView';
import CrisisOverlay from './components/CrisisOverlay';
import { 
  UserRole, Order, OrderStatus, ServiceCategory, Alert, ComplexityLevel, 
  UserContext, SystemMode, CareDigitalTwin, CareScores, DisasterEvent, 
  DisasterType, EmergencyResponse, HumanitarianResponse 
} from './types';
import { MOCK_ELDERLY_USER, INITIAL_ALERTS, UI_STRINGS, PRIVACY_POLICY_URL, TERMS_URL } from './constants';
import { Heart, Globe, ShieldCheck, ChevronRight, LogOut, Waves, Wind, Mountain, Trash2, FileText, User, Radio, Volume2, FastForward, Play } from 'lucide-react';
import { assessEmergencyRisk } from './services/geminiService';
import { audioService } from './services/audioService';

const App: React.FC = () => {
  const [activeRole, setActiveRole] = useState<UserRole>(UserRole.ELDERLY);
  const [currentView, setCurrentView] = useState<string>('HOME');
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [isConsentOpen, setIsConsentOpen] = useState(false);
  const [hasConsented, setHasConsented] = useState(false);
  
  const [activeDisaster, setActiveDisaster] = useState<DisasterEvent | null>(null);
  const [emergencyAIResponse, setEmergencyAIResponse] = useState<EmergencyResponse | undefined>();
  const [systemMode, setSystemMode] = useState<SystemMode>(SystemMode.NORMAL);

  // User Voice Settings
  const [voiceName, setVoiceName] = useState('Kore');
  const [speechSpeed, setSpeechSpeed] = useState<'slow' | 'normal' | 'fast'>('normal');

  const [twin] = useState<CareDigitalTwin>({
    lastKnownMood: 'Happy',
    behavioralPattern: 'Stable',
    vitalThresholds: { heartRate: '72bpm', sleep: '8.2h' },
    culturalPreferences: ['Latin', 'Family focus'],
    educationLevel: 60
  });
  
  const [scores] = useState<CareScores>({
    trust: 98,
    vulnerability: 8,
    stability: 95,
    socialEngagement: 88
  });

  const ctx: UserContext = {
    language: 'pt-BR',
    country: 'Brasil',
    complexity: ComplexityLevel.BALANCED,
    lastActivity: new Date(),
    culturalTheme: 'LATIN',
    mode: systemMode,
    twin,
    scores,
    voiceName,
    speechSpeed
  };

  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'VITA-2025-001',
      category: ServiceCategory.PHARMACY,
      description: 'Vitaminas de rotina',
      status: OrderStatus.DELIVERED,
      timestamp: new Date(Date.now() - 3600000),
      patientName: 'Dona Maria',
      familyApproved: true,
      urgency: 'routine'
    }
  ]);

  useEffect(() => {
    const consent = localStorage.getItem('vitacare_consent');
    if (!consent) setIsConsentOpen(true);
    else setHasConsented(true);
  }, []);

  const handleAcceptConsent = () => {
    audioService.playSuccess();
    localStorage.setItem('vitacare_consent', 'true');
    setHasConsented(true);
    setIsConsentOpen(false);
  };

  const triggerOfficialSignal = async (type: DisasterType, authority: string) => {
    setSystemMode(SystemMode.CRISIS);
    audioService.playEmergency();
    
    const mockEvent: DisasterEvent = {
      type,
      severity: 'SEVERE',
      location: 'Zona Sul - São Paulo',
      timestamp: new Date(),
      guidance: ["Carregando protocolos Luiza..."],
      humanitarian_context: `Sinal via ${authority}.`
    };
    setActiveDisaster(mockEvent);

    const aiResponse = await assessEmergencyRisk(mockEvent, ctx);
    setEmergencyAIResponse(aiResponse);

    setAlerts(prev => [{
      id: `signal-${Date.now()}`,
      title: `ALERTA VITA-SOS: ${type}`,
      message: `Ativamos o protocolo de segurança para Dona Maria.`,
      type: 'danger',
      timestamp: new Date()
    }, ...prev]);
  };

  const renderView = () => {
    if (activeDisaster && activeRole === UserRole.ELDERLY) {
      return (
        <CrisisOverlay 
          disaster={activeDisaster}
          emergencyData={emergencyAIResponse}
          onCallRescue={() => { audioService.playEmergency(); alert("🚨 SOCORRO ACIONADO."); }}
          onCallFamily={() => { audioService.playAction(); alert("📞 Conectando com José..."); }}
          onConfirmSafety={() => { 
            audioService.playSuccess();
            setActiveDisaster(null); 
            setEmergencyAIResponse(undefined);
            setSystemMode(SystemMode.NORMAL); 
          }}
          language={ctx.language}
          mode={systemMode}
        />
      );
    }

    const t = UI_STRINGS[ctx.language as 'pt-BR' | 'en-US'] || UI_STRINGS['en-US'];

    switch (currentView) {
      case 'HOME':
        if (activeRole === UserRole.ELDERLY) return <ElderlyHome onGoToOrder={() => setCurrentView('EASY_ORDER')} onRequestHelp={() => { audioService.playEmergency(); alert("🚨 ALERTA VITA-SOS ENVIADO"); }} unreadCount={alerts.length} userContext={ctx} />;
        if (activeRole === UserRole.FAMILY) return <FamilyDashboard orders={orders} onApprove={(id) => { audioService.playSuccess(); setOrders(p => p.map(o => o.id === id ? {...o, familyApproved: true, status: OrderStatus.PREPARING} : o)); }} onCancel={(id) => { audioService.playAction(); setOrders(p => p.filter(o => o.id !== id)); }} />;
        if (activeRole === UserRole.PROVIDER) return <ProviderPanel orders={orders} onUpdateStatus={(id, s) => { audioService.playAction(); setOrders(p => p.map(o => o.id === id ? {...o, status: s} : o)); }} />;
        if (activeRole === UserRole.PUBLIC_AGENT) return <PublicAgentPanel />;
        if (activeRole === UserRole.PUBLIC_MANAGER) return <PublicManagerDashboard />;
        return null;

      case 'EASY_ORDER':
        return <EasyOrder 
          onBack={() => { audioService.playTick(); setCurrentView('HOME'); }} 
          onOrderCreated={(o) => { 
            audioService.playNotification(); 
            setOrders(p => [...p, o]); 
          }} 
          userContext={ctx} 
        />;

      case 'ORDERS':
        return (
          <div className="space-y-12 animate-fadeIn pb-32">
             <div className="px-4">
                <h2 className="text-7xl font-black tracking-tighter text-gray-950 leading-none uppercase">Luiza AI</h2>
                <p className="text-3xl font-bold mt-4 text-gray-400">Mensagens e Proteção.</p>
             </div>
             {alerts.map(alert => (
                <div key={alert.id} className={`p-10 rounded-[60px] border-l-[24px] shadow-4xl bg-white border-2 border-gray-50 flex flex-col gap-6 ${alert.type === 'danger' ? 'border-l-red-500' : 'border-l-blue-500'}`}>
                  <div className="flex justify-between items-start">
                     <h4 className="font-black text-4xl text-gray-950 tracking-tighter leading-none">{alert.title}</h4>
                     <span className="text-xs font-black text-gray-300 uppercase">{alert.timestamp.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}</span>
                  </div>
                  <p className="text-3xl text-gray-500 font-bold leading-tight">{alert.message}</p>
                  <button onClick={() => { audioService.playAction(); setAlerts(p => p.filter(a => a.id !== alert.id)); }} className="self-end text-gray-200 hover:text-red-400 transition-colors">
                     <Trash2 size={40} />
                  </button>
                </div>
             ))}
          </div>
        );

      case 'PROFILE':
        return (
          <div className="space-y-12 animate-fadeIn pb-32">
            <div className="flex flex-col items-center py-10">
              <div className="w-64 h-64 bg-white rounded-[90px] flex items-center justify-center text-blue-600 mb-10 border-[24px] border-blue-50 shadow-4xl relative">
                <Heart size={120} fill="currentColor" />
                <div className="absolute -bottom-4 bg-blue-600 text-white px-8 py-2 rounded-full font-black text-[10px] uppercase tracking-[0.3em] shadow-2xl">Protegida</div>
              </div>
              <h2 className="text-7xl font-black text-gray-950 tracking-tighter leading-none text-center">Dona Maria</h2>
              <p className="text-2xl font-bold text-gray-400 mt-4 uppercase tracking-widest">ID: {MOCK_ELDERLY_USER.id}</p>
            </div>

            {/* VOICE SETTINGS SECTION */}
            <div className="bg-white p-12 rounded-[70px] shadow-4xl space-y-10 border-4 border-gray-50">
               <div className="flex items-center gap-6 mb-4">
                  <Volume2 className="text-blue-600" size={48} />
                  <h4 className="text-4xl font-black tracking-tighter uppercase leading-none text-gray-900">Configurações de Voz</h4>
               </div>

               {/* Voice Selection */}
               <div className="space-y-6">
                  <p className="text-[12px] font-black uppercase tracking-[0.4em] text-gray-400">Escolha a voz da Luiza</p>
                  <div className="grid grid-cols-2 gap-4">
                     {[
                       { id: 'Kore', label: 'Suave' },
                       { id: 'Zephyr', label: 'Serena' },
                       { id: 'Puck', label: 'Amigável' },
                       { id: 'Charon', label: 'Firme' }
                     ].map(v => (
                       <button
                         key={v.id}
                         onClick={() => { audioService.playTick(); setVoiceName(v.id); }}
                         className={`p-6 rounded-[35px] border-4 flex items-center justify-between transition-all ${
                           voiceName === v.id ? 'bg-blue-600 border-blue-800 text-white shadow-xl' : 'bg-gray-50 border-gray-100 text-gray-500'
                         }`}
                       >
                         <span className="font-black text-xl uppercase tracking-tighter">{v.label}</span>
                         {voiceName === v.id && <Radio size={20} className="animate-pulse" />}
                       </button>
                     ))}
                  </div>
               </div>

               {/* Speed Selection */}
               <div className="space-y-6">
                  <p className="text-[12px] font-black uppercase tracking-[0.4em] text-gray-400">Velocidade da fala</p>
                  <div className="flex gap-4 p-4 bg-gray-50 rounded-[45px] border-4 border-gray-100 shadow-inner">
                     {[
                       { id: 'slow', label: 'Devagar', icon: <Play size={20} /> },
                       { id: 'normal', label: 'Normal', icon: <Play size={32} /> },
                       { id: 'fast', label: 'Rápido', icon: <FastForward size={32} /> }
                     ].map(s => (
                       <button
                         key={s.id}
                         onClick={() => { audioService.playTick(); setSpeechSpeed(s.id as any); }}
                         className={`flex-1 py-8 rounded-[35px] flex flex-col items-center gap-2 transition-all ${
                           speechSpeed === s.id ? 'bg-white text-blue-600 shadow-2xl scale-105 border-2 border-blue-100' : 'text-gray-300'
                         }`}
                       >
                         {s.icon}
                         <span className="font-black text-xs uppercase tracking-widest">{s.label}</span>
                       </button>
                     ))}
                  </div>
               </div>
            </div>

            {/* SIMULATOR FOR TESTING */}
            <div className="bg-[#111827] p-12 rounded-[70px] shadow-4xl space-y-10 border-b-[20px] border-indigo-600">
               <div className="flex items-center gap-6">
                  <Globe className="text-indigo-400" size={40} />
                  <h4 className="text-white font-black text-3xl tracking-tighter uppercase leading-none">Simulador Vita-SOS</h4>
               </div>
               <div className="grid grid-cols-1 gap-6">
                  <button onClick={() => { audioService.playAction(); triggerOfficialSignal(DisasterType.TSUNAMI, 'NOAA'); }} className="bg-white/10 text-white p-8 rounded-[40px] border border-white/10 font-black text-2xl flex items-center gap-6 active:scale-95 transition-all">
                    <Waves size={32} /> Tsunami
                  </button>
                  <button onClick={() => { audioService.playAction(); triggerOfficialSignal(DisasterType.EARTHQUAKE, 'USGS'); }} className="bg-white/10 text-white p-8 rounded-[40px] border border-white/10 font-black text-2xl flex items-center gap-6 active:scale-95 transition-all">
                    <Mountain size={32} /> Terremoto
                  </button>
               </div>
            </div>

            <div className="bg-white p-10 rounded-[70px] shadow-4xl space-y-8">
               <h4 className="text-[12px] font-black uppercase tracking-[0.4em] text-gray-300 px-4">Configurações</h4>
               <a href={PRIVACY_POLICY_URL} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-8 bg-gray-50 rounded-[40px] active:scale-95 transition-all">
                  <div className="flex items-center gap-6">
                     <ShieldCheck className="text-blue-600" size={32} />
                     <span className="text-3xl font-black">{t.legalPrivacy}</span>
                  </div>
                  <ChevronRight size={32} className="text-gray-300" />
               </a>
               <a href={TERMS_URL} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-8 bg-gray-50 rounded-[40px] active:scale-95 transition-all">
                  <div className="flex items-center gap-6">
                     <FileText className="text-blue-600" size={32} />
                     <span className="text-3xl font-black">{t.legalTerms}</span>
                  </div>
                  <ChevronRight size={32} className="text-gray-300" />
               </a>
               <button onClick={() => { audioService.playAction(); alert("Logout process initiated."); }} className="w-full text-red-500 py-10 rounded-[40px] font-black text-4xl flex items-center justify-center gap-6 hover:bg-red-50 transition-colors">
                 <LogOut size={48} /> Sair do App
               </button>
            </div>
          </div>
        );

      case 'DASHBOARD':
        return <DigitalTwinView context={ctx} />;

      default:
        return null;
    }
  };

  return (
    <Layout 
      activeRole={activeRole} 
      onRoleChange={(role) => { setActiveRole(role); setCurrentView('HOME'); }} 
      currentView={currentView}
      onViewChange={setCurrentView}
      language={ctx.language as 'pt-BR' | 'en-US'}
      mode={systemMode}
    >
      <ConsentModal 
        isOpen={isConsentOpen} 
        onAccept={handleAcceptConsent}
        onDecline={() => { audioService.playAction(); setIsConsentOpen(false); }}
        language={ctx.language}
      />
      {renderView()}
    </Layout>
  );
};

export default App;
