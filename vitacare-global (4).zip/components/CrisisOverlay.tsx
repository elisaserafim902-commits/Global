
import React, { useEffect, useState } from 'react';
import { 
  ShieldAlert, PhoneCall, Zap, Waves, Mountain, Wind, 
  Droplets, Flame, Biohazard, CheckCircle,
  ShieldCheck, AlertTriangle, Info, OctagonX, Globe,
  ShieldEllipsis, Radio, Volume2, Share2
} from 'lucide-react';
import { DisasterEvent, DisasterType, SystemMode, EmergencyResponse, HumanitarianResponse } from '../types';
import { DISASTER_META } from '../constants';
import { audioService } from '../services/audioService';

interface CrisisOverlayProps {
  disaster: DisasterEvent;
  emergencyData?: EmergencyResponse;
  humanitarianData?: HumanitarianResponse;
  onCallRescue: () => void;
  onCallFamily: () => void;
  onConfirmSafety: () => void;
  language: string;
  mode: SystemMode;
}

const DisasterIcon = ({ type }: { type: DisasterType }) => {
  const size = 64;
  const strokeWidth = 2.5;
  switch (type) {
    case DisasterType.TSUNAMI: return <Waves size={size} strokeWidth={strokeWidth} />;
    case DisasterType.EARTHQUAKE: return <Mountain size={size} strokeWidth={strokeWidth} />;
    case DisasterType.CYCLONE: return <Wind size={size} strokeWidth={strokeWidth} />;
    case DisasterType.FLOOD: return <Droplets size={size} strokeWidth={strokeWidth} />;
    case DisasterType.WILDFIRE: return <Flame size={size} strokeWidth={strokeWidth} />;
    case DisasterType.EPIDEMIC: return <Biohazard size={size} strokeWidth={strokeWidth} />;
    default: return <ShieldAlert size={size} strokeWidth={strokeWidth} />;
  }
};

const CrisisOverlay: React.FC<CrisisOverlayProps> = ({ 
  disaster, emergencyData, onCallRescue, onCallFamily, onConfirmSafety, language, mode 
}) => {
  const meta = DISASTER_META[disaster.type] || { label: 'Alerta Oficial', color: 'bg-red-900', icon: 'ShieldAlert', guideScript: "Atenção. Estamos aqui com você." };
  const [showVoiceGuide, setShowVoiceGuide] = useState(true);
  
  const alertSource = emergencyData?.source || "SISTEMA DE ALERTA GLOBAL";

  const handleShare = async () => {
    audioService.playAction();
    const shareTitle = emergencyData?.title || `Alerta VitaCare: ${meta.label}`;
    const shareText = `⚠️ Alerta VitaCare - ${meta.label}\n\n📍 Local: ${disaster.location}\n📢 Fonte: ${alertSource}\n\nO que está havendo: ${emergencyData?.what_is_happening || 'Alerta de emergência'}\n\nO que fazer agora:\n${(emergencyData?.what_to_do_now || disaster.guidance).map((step, i) => `${i + 1}. ${step}`).join('\n')}\n\nNota: ${emergencyData?.important_note || 'Fique seguro.'}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error('Erro ao compartilhar:', err);
        }
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareText);
        window.alert('Detalhes copiados para a área de transferência.');
      } catch (err) {
        console.error('Erro ao copiar:', err);
      }
    }
  };

  return (
    <div className={`fixed inset-0 z-[200] ${meta.color} text-white flex flex-col font-sans animate-fadeIn overflow-hidden selection:bg-white/30`}>
      {/* SCROLLABLE CONTENT AREA */}
      <div className="flex-1 overflow-y-auto px-6 pt-12 pb-80 space-y-10 scroll-smooth">
        
        {/* HEADER */}
        <header className="flex flex-col items-center text-center max-w-lg mx-auto">
           <div className="bg-white text-red-600 p-7 rounded-[45px] mb-8 shadow-4xl relative border-4 border-white/20 transform transition-transform hover:scale-105">
              <DisasterIcon type={disaster.type} />
              <div className="absolute -top-3 -right-3 bg-amber-400 p-2.5 rounded-full text-white animate-pulse shadow-xl border-4 border-white">
                 <AlertTriangle size={24} />
              </div>
           </div>
           
           <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tighter uppercase leading-[0.9] mb-4 drop-shadow-2xl">
              {emergencyData?.title || "GUIDE: ORIENTAÇÃO DE SEGURANÇA"}
           </h1>

           <div className="flex flex-wrap justify-center gap-4 mt-2">
              <div className="flex items-center gap-3 bg-black/30 px-6 py-2.5 rounded-full border border-white/20 backdrop-blur-xl">
                 <Globe size={18} className="text-blue-300" />
                 <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-90">FONTE:</span>
                 <span className="text-[10px] font-black uppercase text-blue-100">{alertSource}</span>
              </div>
              <button 
                 onClick={handleShare}
                 className="bg-white/10 hover:bg-white/20 px-6 py-2.5 rounded-full border border-white/30 flex items-center gap-2 active:scale-95 transition-all shadow-lg backdrop-blur-md"
              >
                 <Share2 size={18} />
                 <span className="text-[10px] font-black uppercase tracking-widest">Compartilhar</span>
              </button>
           </div>
        </header>

        {/* VOICE GUIDE */}
        {showVoiceGuide && (
          <section className="bg-black/40 backdrop-blur-3xl p-8 rounded-[45px] border-2 border-white/10 shadow-2xl animate-slideUp max-w-lg mx-auto w-full">
             <div className="flex items-center gap-4 mb-5">
                <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-500/30">
                   <Volume2 size={28} className="animate-pulse" />
                </div>
                <span className="text-[11px] font-black uppercase tracking-[0.4em] text-blue-400">GUIA DE VOZ GUIDE</span>
             </div>
             <p className="text-2xl sm:text-3xl font-black italic leading-[1.1] tracking-tight text-blue-50">
                "{meta.guideScript}"
             </p>
          </section>
        )}

        {/* CONTENT STRUCTURE */}
        <div className="space-y-10 max-w-lg mx-auto w-full">
          
          {/* WHAT IS HAPPENING */}
          <section className="bg-white/10 backdrop-blur-2xl p-8 rounded-[45px] border border-white/10 shadow-inner">
             <h3 className="text-[11px] font-black uppercase tracking-[0.5em] text-white/60 mb-5 flex items-center gap-2">
                <Info size={16} /> O QUE ESTÁ HAVENDO
             </h3>
             <p className="text-2xl sm:text-3xl font-black leading-tight tracking-tight opacity-100">
                "{emergencyData?.what_is_happening || "Sinal oficial de alerta detectado para sua localização atual."}"
             </p>
          </section>

          {/* WHAT TO DO NOW */}
          <section className="bg-white p-10 rounded-[55px] text-gray-950 shadow-4xl border-b-[20px] border-gray-200">
             <h3 className="text-xs font-black uppercase tracking-[0.5em] text-blue-600 mb-10 flex items-center gap-3">
                <ShieldCheck size={32} /> AÇÕES IMEDIATAS
             </h3>
             <div className="space-y-8">
                {(emergencyData?.what_to_do_now || disaster.guidance).map((step, i) => (
                  <div key={i} className="flex items-start gap-6 group">
                     <div className="w-14 h-14 bg-blue-600 rounded-3xl flex items-center justify-center font-black text-white text-3xl flex-shrink-0 shadow-xl group-hover:scale-110 transition-transform">
                        {i + 1}
                     </div>
                     <p className="text-2xl sm:text-3xl font-black leading-[1.1] text-gray-900 tracking-tighter">{step}</p>
                  </div>
                ))}
             </div>
          </section>

          {/* WHAT TO AVOID */}
          <section className="bg-red-950/60 backdrop-blur-2xl p-8 rounded-[45px] border-2 border-red-500/20">
             <h3 className="text-xs font-black uppercase tracking-[0.5em] text-red-400 mb-8 flex items-center gap-3">
                <OctagonX size={32} /> RISCOS A EVITAR
             </h3>
             <div className="space-y-6">
                {(emergencyData?.what_to_avoid || ["Não entre em pânico", "Ignore boatos"]).map((step, i) => (
                  <div key={i} className="flex items-start gap-5 opacity-90">
                     <div className="w-10 h-10 bg-red-500/20 rounded-2xl flex items-center justify-center font-black text-red-200 text-2xl flex-shrink-0 border border-red-500/30">
                        ×
                     </div>
                     <p className="text-xl sm:text-2xl font-bold leading-tight">{step}</p>
                  </div>
                ))}
             </div>
          </section>

          {/* IMPORTANT NOTE */}
          <div className="text-center px-8 py-8 bg-black/30 rounded-[40px] border border-white/10 mb-4">
             <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-white/40 mb-4 flex items-center justify-center gap-2">
               <ShieldEllipsis size={18} /> PROTOCOLO VITA-SOS
             </h4>
             <p className="text-xl sm:text-2xl font-bold opacity-100 leading-relaxed italic text-white/90">
                {emergencyData?.important_note || "Fique calmo. Ativamos a rede de monitoramento para sua proteção."}
             </p>
          </div>
        </div>
      </div>

      {/* FIXED BOTTOM ACTIONS - OPTIMIZED FOR LARGE TOUCH AREA */}
      <div className="fixed bottom-0 left-0 right-0 p-6 pb-10 bg-gradient-to-t from-black/95 via-black/80 to-transparent pointer-events-none z-[250]">
        <div className="max-w-md mx-auto pointer-events-auto space-y-5">
           
           <button 
             onClick={() => { audioService.playSuccess(); onConfirmSafety(); }}
             className="w-full bg-emerald-500 hover:bg-emerald-400 text-white py-10 rounded-[40px] font-black text-3xl sm:text-4xl shadow-[0_20px_50px_rgba(16,185,129,0.4)] flex items-center justify-center gap-4 border-b-[16px] border-emerald-800 active:translate-y-4 active:border-b-0 transition-all"
           >
             <CheckCircle size={44} /> ESTOU EM SEGURANÇA
           </button>

           <div className="grid grid-cols-2 gap-5">
             <button 
               onClick={onCallRescue} 
               className="bg-white text-red-600 py-9 rounded-[35px] font-black text-2xl sm:text-3xl shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all border-b-[10px] border-gray-200"
             >
               <Zap size={28} fill="currentColor" /> SOCORRO
             </button>
             
             <button 
               onClick={onCallFamily} 
               className="bg-[#111827] text-white py-9 rounded-[35px] font-black text-2xl sm:text-3xl shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all border-b-[10px] border-blue-900"
             >
               <PhoneCall size={28} /> FAMÍLIA
             </button>
           </div>
           
           {/* Visual Safe Area Spacer for notch devices */}
           <div className="h-2 w-1/3 bg-white/10 mx-auto rounded-full mt-2" />
        </div>
      </div>
    </div>
  );
};

export default CrisisOverlay;
