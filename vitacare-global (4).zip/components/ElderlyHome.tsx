
import React, { useState } from 'react';
import { UI_STRINGS } from '../constants';
import { ComplexityLevel, UserContext, SystemMode } from '../types';
import { Mic, Heart, Shield, Sparkles, AlertCircle, Waves, Sun, Moon, MessageSquareHeart, Users, Activity, ShieldAlert, Phone, HelpCircle, AudioLines } from 'lucide-react';
import { audioService } from '../services/audioService';
import AdaptiveUI from './AdaptiveUI';
import LiveVoiceAssistant from './LiveVoiceAssistant';

interface ElderlyHomeProps {
  onGoToOrder: () => void;
  onRequestHelp: () => void;
  unreadCount: number;
  userContext: UserContext;
}

const ElderlyHome: React.FC<ElderlyHomeProps> = ({ 
  onGoToOrder, onRequestHelp, unreadCount, userContext 
}) => {
  const { language, complexity, mode, voiceName, speechSpeed } = userContext;
  const t = UI_STRINGS[language as 'pt-BR' | 'en-US'] || UI_STRINGS['en-US'];
  const isCrisis = mode === SystemMode.CRISIS;
  const [showVoiceAssistant, setShowVoiceAssistant] = useState(false);

  const handleHelp = () => {
    // Haptic feedback for emergency
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 100]);
    }
    audioService.playEmergency();
    onRequestHelp();
  };

  const handleAction = (cb: () => void) => {
    // Subtle haptic feedback for general actions
    if (navigator.vibrate) {
      navigator.vibrate(20);
    }
    audioService.playAction();
    cb();
  };

  const getTimeIcon = () => {
    const hour = new Date().getHours();
    if (hour < 12) return <Sun className="text-amber-500" size={64} />;
    if (hour < 18) return <Sun className="text-orange-500" size={64} />;
    return <Moon className="text-indigo-500" size={64} />;
  };

  const BalancedView = (
    <div className="space-y-10 pb-20 animate-slideUp">
      {/* LUIZA & FAMILY PRESENCE CARD */}
      <div className={`p-10 rounded-[60px] shadow-4xl border-4 transition-all duration-500 ${
        isCrisis ? 'bg-red-600 border-red-700 text-white' : 'bg-white border-blue-50'
      }`}>
        <div className="flex items-center justify-between mb-8">
           <div className="flex items-center gap-6">
              <div className="relative">
                 <div className="w-24 h-24 bg-blue-600 rounded-[35px] flex items-center justify-center text-white shadow-xl shadow-blue-200">
                    <Sparkles size={48} className="animate-pulse" />
                 </div>
                 <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-emerald-500 rounded-full border-4 border-white flex items-center justify-center text-white">
                    <div className="w-3 h-3 bg-white rounded-full animate-ping" />
                 </div>
              </div>
              <div>
                 <p className="text-[12px] font-black uppercase tracking-[0.4em] text-blue-400">LUÍZA ASSISTENTE</p>
                 <h3 className="text-4xl font-black tracking-tighter uppercase leading-none text-gray-900">Online Agora</h3>
              </div>
           </div>
           <div className="text-right">
              <div className="flex -space-x-4 mb-2">
                 {[1, 2].map(i => (
                    <div key={i} className="w-12 h-12 rounded-full border-4 border-white bg-indigo-100 flex items-center justify-center text-indigo-600">
                       <Users size={20} />
                    </div>
                 ))}
              </div>
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Família Olhando</p>
           </div>
        </div>
        
        <div className="bg-blue-50/50 rounded-[45px] p-8 border-2 border-blue-100/50">
           <p className="text-3xl font-bold text-blue-900 leading-tight">
             "Olá Maria! Falei com seu filho José há 10 minutos. Ele mandou um beijo e disse que está tudo bem."
           </p>
        </div>
      </div>

      <header className="px-6">
         <div className="flex items-center gap-8">
            <div className="bg-white p-6 rounded-[45px] shadow-2xl border-4 border-gray-50">
               {getTimeIcon()}
            </div>
            <div>
               <h2 className="text-7xl font-black text-gray-950 leading-none tracking-tighter">Oi, Maria</h2>
               <p className="text-3xl font-bold text-gray-400 mt-2">Como posso te ajudar?</p>
            </div>
         </div>
      </header>

      {/* CORE ACTIONS */}
      <div className="grid grid-cols-1 gap-10">
        <button 
          onClick={() => handleAction(() => setShowVoiceAssistant(true))}
          className="relative overflow-hidden bg-[#0f172a] p-14 rounded-[80px] shadow-4xl border-4 border-blue-900 group active:scale-95 transition-all text-left"
        >
          <div className="flex items-center justify-between mb-10">
            <div className="bg-blue-600 p-10 rounded-[45px] text-white shadow-2xl shadow-blue-300">
               <AudioLines size={80} strokeWidth={2.5} className="animate-pulse" />
            </div>
            <div className="bg-white/10 px-8 py-4 rounded-full border-2 border-white/20">
               <span className="text-sm font-black text-white uppercase tracking-[0.2em]">Falar ao Vivo</span>
            </div>
          </div>
          <h3 className="text-6xl font-black text-white tracking-tighter mb-4 leading-none uppercase">Conversar</h3>
          <p className="text-3xl text-blue-200 font-bold opacity-70">Fale naturalmente com a Luiza agora.</p>
        </button>

        <button 
          onClick={() => handleAction(onGoToOrder)}
          className="relative overflow-hidden bg-white p-14 rounded-[80px] shadow-4xl border-4 border-blue-50 group active:scale-95 transition-all text-left"
        >
          <div className="flex items-center justify-between mb-10">
            <div className="bg-gray-100 p-10 rounded-[45px] text-blue-600 shadow-xl border border-gray-100">
               <Mic size={80} strokeWidth={2.5} />
            </div>
            <div className="bg-blue-50 px-8 py-4 rounded-full border-2 border-blue-100">
               <span className="text-sm font-black text-blue-600 uppercase tracking-[0.2em]">Escrever Pedido</span>
            </div>
          </div>
          <h3 className="text-6xl font-black text-gray-950 tracking-tighter mb-4 leading-none uppercase">Pedir Algo</h3>
          <p className="text-3xl text-gray-400 font-bold">Comida, remédios ou ajuda rápida.</p>
        </button>

        <div className="grid grid-cols-2 gap-8">
           <button 
             onClick={() => handleAction(() => alert("📞 Ligando para José..."))}
             className="bg-indigo-50 p-12 rounded-[70px] border-4 border-indigo-100 flex flex-col items-center gap-6 shadow-xl active:scale-95 transition-all"
           >
              <div className="bg-white p-8 rounded-[40px] shadow-xl text-indigo-600">
                 <Phone size={56} />
              </div>
              <span className="text-3xl font-black text-indigo-900 uppercase tracking-tighter">Ligar Filho</span>
           </button>
           <button 
             onClick={handleHelp}
             className="bg-red-50 p-12 rounded-[70px] border-4 border-red-100 flex flex-col items-center gap-6 shadow-xl active:scale-95 transition-all"
           >
              <div className="bg-white p-8 rounded-[40px] shadow-xl text-red-600">
                 <AlertCircle size={56} />
              </div>
              <span className="text-3xl font-black text-red-900 uppercase tracking-tighter">Socorro</span>
           </button>
        </div>
      </div>

      <div className="bg-[#111827] p-12 rounded-[75px] text-white flex items-center justify-between shadow-4xl border-b-[20px] border-blue-600">
         <div>
            <h4 className="text-[12px] font-black text-blue-400 uppercase tracking-[0.4em] mb-2">MODO DE PROTEÇÃO</h4>
            <p className="text-4xl font-black tracking-tighter leading-none">CASA BLINDADA</p>
         </div>
         <div className="bg-white/10 p-6 rounded-[35px]">
            <Shield size={56} className="text-emerald-400" />
         </div>
      </div>

      {showVoiceAssistant && (
        <LiveVoiceAssistant 
          onClose={() => setShowVoiceAssistant(false)} 
          voiceName={voiceName}
          systemInstruction={`
            You are 'Guide', the living humanoid orientation intelligence of VitaCare Global.
            You sound human, calm, and highly intelligent. Your voice is ${speechSpeed === 'slow' ? 'VERY slow' : speechSpeed === 'fast' ? 'energetic and quick' : 'warm and naturally paced'}.
            
            CORE RESPONSIBILITY:
            - Ensure the user Maria feels safe, cared for, and heard.
            - Provide clear guidance for her needs (food, medicine, companionship).
            - Always cite that you are listening and can contact her son Jose if needed.
            
            TONE: Very patient, empathetic, and organized. Use short, clear sentences.
            IMPORTANT: Speak ${speechSpeed === 'slow' ? 'much slower than normal' : speechSpeed === 'fast' ? 'slightly faster than normal' : 'at a normal human conversation speed'}.
          `} 
        />
      )}
    </div>
  );

  return (
    <AdaptiveUI 
      level={complexity}
      minimal={<div className="p-20 text-center font-black text-4xl">VitaCare Modo Essencial Ativo.</div>}
      balanced={BalancedView}
    />
  );
};

export default ElderlyHome;
