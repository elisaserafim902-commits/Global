
import React from 'react';
import { COLORS } from '../constants';
import { Order, OrderStatus } from '../types';
import { CheckCircle2, XCircle, Clock, AlertCircle, Heart, Shield, Sparkles, UserCheck, Activity, Brain, ShieldCheck, MapPin, ChevronRight } from 'lucide-react';

interface FamilyDashboardProps {
  orders: Order[];
  onApprove: (id: string) => void;
  onCancel: (id: string) => void;
}

const FamilyDashboard: React.FC<FamilyDashboardProps> = ({ orders, onApprove, onCancel }) => {
  const pendingOrders = orders.filter(o => !o.familyApproved && o.status === OrderStatus.RECEIVED);
  const activeOrders = orders.filter(o => o.familyApproved || o.status !== OrderStatus.RECEIVED);

  return (
    <div className="space-y-12 animate-fadeIn pb-24">
      {/* HEADER INTEGRADO */}
      <div className="flex justify-between items-end px-4">
        <div>
          <p className="text-[12px] font-black text-blue-600 uppercase tracking-[0.4em] mb-2">REDE DE AFETO</p>
          <h2 className="text-5xl font-black text-gray-900 tracking-tighter uppercase leading-none">Dona Maria</h2>
        </div>
        <div className="bg-emerald-50 text-emerald-600 px-6 py-3 rounded-3xl border-2 border-emerald-100 flex items-center gap-3">
           <Activity size={24} className="animate-pulse" />
           <span className="font-black text-sm uppercase">Estável</span>
        </div>
      </div>

      {/* HEALTH STATUS CARD (SIMULATED DIGITAL TWIN) */}
      <section className="bg-[#111827] p-10 rounded-[60px] shadow-4xl text-white relative overflow-hidden border-b-[24px] border-indigo-600">
         <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
         <div className="flex justify-between items-start mb-10 relative z-10">
            <div className="flex items-center gap-4">
               <div className="bg-white/10 p-5 rounded-[30px] border border-white/10">
                  <Brain size={48} className="text-indigo-400" />
               </div>
               <div>
                  <h3 className="text-3xl font-black tracking-tighter uppercase">Bem-estar Mental</h3>
                  <p className="text-indigo-300 font-bold text-lg opacity-80">92% Estabilidade</p>
               </div>
            </div>
            <Sparkles size={32} className="text-amber-400 animate-pulse" />
         </div>

         <div className="grid grid-cols-2 gap-6 relative z-10">
            <div className="bg-white/5 p-8 rounded-[40px] border border-white/10 text-center">
               <Heart size={32} className="text-red-400 mx-auto mb-4" fill="currentColor" />
               <p className="text-sm font-black opacity-40 uppercase tracking-widest mb-1">Batimentos</p>
               <p className="text-4xl font-black">72 <span className="text-xl opacity-50">bpm</span></p>
            </div>
            <div className="bg-white/5 p-8 rounded-[40px] border border-white/10 text-center">
               <ShieldCheck size={32} className="text-emerald-400 mx-auto mb-4" />
               <p className="text-sm font-black opacity-40 uppercase tracking-widest mb-1">Segurança</p>
               <p className="text-4xl font-black">100<span className="text-xl opacity-50">%</span></p>
            </div>
         </div>
      </section>

      {/* PENDING APPROVALS */}
      <section className="space-y-8">
        <div className="flex items-center justify-between px-4">
          <h3 className="font-black text-4xl text-gray-900 tracking-tighter uppercase">Ações Necessárias</h3>
          <span className="bg-amber-100 text-amber-600 px-5 py-2 rounded-full font-black text-xs uppercase">{pendingOrders.length}</span>
        </div>
        
        {pendingOrders.length === 0 ? (
          <div className="bg-gray-50 border-4 border-dashed border-gray-100 p-14 rounded-[60px] text-center">
            <Shield className="mx-auto text-gray-200 mb-6" size={80} />
            <p className="text-3xl font-black text-gray-300 uppercase tracking-tighter">Nenhuma ajuda pendente</p>
            <p className="text-xl text-gray-400 font-bold mt-2">Maria está confortável agora.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {pendingOrders.map(order => (
              <div key={order.id} className="bg-white border-4 border-amber-50 p-10 rounded-[60px] shadow-3xl">
                <div className="flex justify-between items-start mb-6">
                  <span className="text-xs font-black bg-amber-500 text-white px-5 py-2 rounded-2xl uppercase tracking-widest">{order.category}</span>
                  <span className="text-sm text-gray-400 font-bold">{order.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p className="text-gray-950 font-black text-4xl mb-10 leading-tight">"Maria quer {order.description.toLowerCase()}"</p>
                <div className="flex gap-4">
                  <button 
                    onClick={() => onApprove(order.id)}
                    className="flex-[2] bg-blue-600 text-white py-8 rounded-[40px] font-black text-3xl shadow-xl active:scale-95 transition-all border-b-[12px] border-blue-900"
                  >
                    Autorizar
                  </button>
                  <button 
                    onClick={() => onCancel(order.id)}
                    className="flex-1 bg-gray-100 text-gray-400 py-8 rounded-[40px] font-black text-2xl active:scale-95"
                  >
                    Negar
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ACTIVITY TIMELINE */}
      <section className="space-y-8">
        <div className="flex items-center justify-between px-4">
           <h3 className="font-black text-4xl text-gray-900 tracking-tighter uppercase">Histórico de Cuidado</h3>
           <Clock size={32} className="text-gray-300" />
        </div>
        
        <div className="bg-white rounded-[60px] border-4 border-gray-50 shadow-2xl overflow-hidden divide-y-4 divide-gray-50">
           {activeOrders.slice(0, 5).map(order => (
             <div key={order.id} className="p-10 flex items-center justify-between group hover:bg-blue-50/30 transition-colors">
                <div className="flex items-center gap-8">
                   <div className={`p-5 rounded-[28px] ${
                     order.status === OrderStatus.DELIVERED ? 'bg-emerald-50 text-emerald-500' : 'bg-blue-50 text-blue-500'
                   }`}>
                      {order.status === OrderStatus.DELIVERED ? <CheckCircle2 size={36} /> : <Clock size={36} />}
                   </div>
                   <div>
                      <p className="font-black text-gray-950 text-2xl leading-none mb-1">{order.description}</p>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">
                         {order.status} • {order.timestamp.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                      </p>
                   </div>
                </div>
                <ChevronRight size={32} className="text-gray-200" />
             </div>
           ))}
        </div>
      </section>

      {/* QUICK ACTIONS */}
      <div className="grid grid-cols-1 gap-6 px-4">
         <button className="w-full bg-blue-50 text-blue-600 py-10 rounded-[45px] font-black text-3xl flex items-center justify-center gap-4 border-2 border-blue-100 shadow-xl shadow-blue-50 active:scale-95 transition-all">
            <MapPin size={32} /> Ver Localização Agora
         </button>
      </div>
    </div>
  );
};

export default FamilyDashboard;
