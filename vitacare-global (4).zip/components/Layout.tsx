
import React, { useState, useEffect } from 'react';
import { UserRole, SystemMode } from '../types';
import { UI_STRINGS } from '../constants';
import { Home, User, Users, Bell, Shield, Globe, AlertTriangle, WifiOff, HeartHandshake, LayoutDashboard, Info, Save, Radio, Check, RadioTower } from 'lucide-react';
import { audioService } from '../services/audioService';

interface LayoutProps {
  children: React.ReactNode;
  activeRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  currentView: string;
  onViewChange: (view: string) => void;
  language: 'pt-BR' | 'en-US';
  mode: SystemMode;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, activeRole, onRoleChange, currentView, onViewChange, language, mode 
}) => {
  const t = UI_STRINGS[language] || UI_STRINGS['pt-BR'];
  const isCrisis = mode === SystemMode.CRISIS;
  const isHumanitarian = mode === SystemMode.HUMANITARIAN;
  const isOffline = mode === SystemMode.OFFLINE;

  const [isSaved, setIsSaved] = useState(false);

  // Load preferences on mount
  useEffect(() => {
    try {
      const savedRole = localStorage.getItem('vitacare_pref_role') as UserRole;
      const savedView = localStorage.getItem('vitacare_pref_view');

      if (savedRole && Object.values(UserRole).includes(savedRole) && savedRole !== activeRole) {
        onRoleChange(savedRole);
      }
      if (savedView && savedView !== currentView) {
        onViewChange(savedView);
      }
    } catch (e) {
      console.error("Failed to load layout preferences from localStorage:", e);
    }
  }, []);

  const handleViewChange = (view: string) => {
    audioService.playTick();
    onViewChange(view);
  };

  const handleRoleChange = (role: UserRole) => {
    audioService.playTick();
    onRoleChange(role);
  };

  const handleSaveLayout = () => {
    audioService.playSuccess();
    try {
      // Persist preferences
      localStorage.setItem('vitacare_pref_role', activeRole);
      localStorage.setItem('vitacare_pref_view', currentView);
      
      // Visual feedback state
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 3000);
      
    } catch (e) {
      console.error("Failed to save layout preferences to localStorage:", e);
    }
  };

  return (
    <div className={`min-h-screen flex flex-col max-w-md mx-auto shadow-4xl relative overflow-hidden font-sans transition-colors duration-700 ${
      isCrisis ? 'bg-red-50' : 
      isHumanitarian ? 'bg-indigo-50' : 
      isOffline ? 'bg-slate-100 grayscale-[0.3]' : 'bg-white'
    }`}>
      {/* Premium Header */}
      <header className={`px-10 py-12 border-b-8 flex justify-between items-center sticky top-0 backdrop-blur-xl z-[60] transition-all duration-500 ${
        isCrisis ? 'bg-red-600 border-red-800 shadow-2xl' : 
        isHumanitarian ? 'bg-[#0f172a] border-indigo-600 shadow-2xl' : 
        isOffline ? 'bg-slate-700 border-slate-900 border-t-[12px] border-t-slate-500 shadow-inner' :
        'bg-white border-blue-50 shadow-sm'
      }`}>
        <div className="cursor-pointer" onClick={() => handleViewChange('HOME')}>
          <div className="flex items-center gap-3">
            <h1 className={`text-5xl font-black tracking-tighter uppercase leading-none transition-colors ${
              (isCrisis || isHumanitarian || isOffline) ? 'text-white' : 'text-blue-600'
            }`}>
              {t.appName}
            </h1>
            {isOffline && (
              <div className="flex items-center gap-2 bg-slate-500/30 px-3 py-1 rounded-full border border-white/10">
                 <RadioTower size={14} className="text-white animate-pulse" />
                 <span className="text-white text-[10px] font-black tracking-widest">LOCAL</span>
              </div>
            )}
          </div>
          <div className="flex items-center mt-2">
            <div className={`w-3 h-3 rounded-full mr-3 ${
              isCrisis || isHumanitarian ? 'bg-white animate-pulse' : 
              isOffline ? 'bg-slate-400 animate-pulse' : 'bg-emerald-500'
            }`} />
            <p className={`text-[12px] font-black tracking-[0.5em] uppercase transition-colors ${
              isCrisis || isHumanitarian || isOffline ? 'text-white/70' : 'text-gray-400'
            }`}>
              {isHumanitarian ? 'PROTEÇÃO ATIVA' : isOffline ? 'REDE EM MALHA' : 'SISTEMA GUIDE'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={handleSaveLayout}
            className={`flex items-center gap-2 px-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 ${
              isSaved 
                ? 'bg-emerald-500 text-white border border-emerald-600 shadow-lg' :
              (isCrisis || isHumanitarian) 
                ? 'bg-white/10 text-white border border-white/20' :
              isOffline 
                ? 'bg-slate-600 text-white border border-slate-500' :
                'bg-gray-100 text-gray-500 border border-gray-200'
            }`}
          >
            {isSaved ? <Check size={16} className="animate-bounce" /> : <Save size={16} />}
            <span className="hidden sm:inline">{isSaved ? 'Salvo' : 'Salvar'}</span>
          </button>

          {isOffline && <WifiOff className="text-white/40" size={32} />}
          {isCrisis && <AlertTriangle className="text-white animate-pulse" size={32} />}
          
          <div className="relative">
            <select 
              value={activeRole} 
              onChange={(e) => handleRoleChange(e.target.value as UserRole)}
              className={`appearance-none text-[12px] font-black px-8 py-5 pr-14 rounded-[30px] border-none focus:ring-12 focus:ring-blue-100 cursor-pointer shadow-xl transition-all active:scale-90 ${
                isCrisis ? 'bg-red-900 text-white' : 
                isHumanitarian ? 'bg-indigo-900 text-white' : 
                isOffline ? 'bg-slate-900 text-white border border-white/10' :
                'bg-blue-600 text-white'
              }`}
            >
              <option value={UserRole.ELDERLY}>IDOSO</option>
              <option value={UserRole.FAMILY}>FAMÍLIA</option>
              <option value={UserRole.PROVIDER}>CUIDADOR</option>
              <option value={UserRole.PUBLIC_AGENT}>AGENTE</option>
              <option value={UserRole.PUBLIC_MANAGER}>GESTÃO</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-5 text-white">
              <Globe size={20} />
            </div>
          </div>
        </div>
      </header>

      {/* Adaptive Canvas */}
      <main className="flex-1 px-10 py-12 pb-48 overflow-y-auto overflow-x-hidden">
        {isOffline && (
          <div className="mb-8 p-8 bg-slate-800 border-4 border-slate-900 rounded-[50px] flex items-center gap-6 animate-slideUp shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
               <RadioTower size={80} className="text-white" />
            </div>
            <div className="bg-slate-900 p-6 rounded-3xl text-white border border-white/5 relative z-10">
              <Radio className="animate-pulse" size={40} />
            </div>
            <div className="relative z-10">
              <p className="font-black text-white text-3xl uppercase tracking-tighter leading-none mb-1">Rede de Rádio Ativa</p>
              <p className="font-bold text-slate-400 text-xl leading-snug">Conexão via malha local Vita-Net segura.</p>
            </div>
          </div>
        )}
        {children}
        
        {/* Play Store Compliance Disclaimer */}
        <div className="mt-16 mb-24 px-4 py-8 bg-gray-50 rounded-[40px] border-2 border-gray-100 text-center flex flex-col items-center">
           <Info size={32} className="text-gray-400 mb-4" />
           <p className="text-sm font-bold text-gray-400 leading-snug">
              {t.disclaimer}
           </p>
           <div className="flex gap-4 mt-6">
              <span className="text-[10px] font-black uppercase text-gray-300 tracking-widest">v2.5.0-Guide</span>
              <span className="text-[10px] font-black uppercase text-gray-300 tracking-widest">•</span>
              <span className="text-[10px] font-black uppercase text-gray-300 tracking-widest">Global Security Protocol</span>
           </div>
        </div>
      </main>

      {/* Futuristic Navigation */}
      <nav className={`fixed bottom-0 left-0 right-0 max-w-md mx-auto border-t-8 py-10 flex justify-around items-center px-10 shadow-[0_-40px_100px_rgba(0,0,0,0.15)] z-[100] backdrop-blur-3xl transition-all duration-500 ${
        isCrisis ? 'bg-red-950 border-red-900' : 
        isHumanitarian ? 'bg-[#0f172a] border-indigo-950' : 
        isOffline ? 'bg-slate-800 border-slate-900 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]' :
        'bg-white/95 border-blue-50'
      }`}>
        {[
          { id: 'HOME', icon: Home, label: 'Início' },
          { id: 'ORDERS', icon: Bell, label: 'Alertas', role: UserRole.ELDERLY },
          { id: 'DASHBOARD', icon: LayoutDashboard, label: 'Saúde', roles: [UserRole.ELDERLY, UserRole.FAMILY] },
          { id: 'MANAGEMENT', icon: Shield, label: 'Gestão', roles: [UserRole.PUBLIC_AGENT, UserRole.PUBLIC_MANAGER] },
          { id: 'PROFILE', icon: User, label: 'Conta' }
        ].filter(n => !n.role || activeRole === n.role || (n.roles && n.roles.includes(activeRole))).map(item => (
          <button 
            key={item.id}
            onClick={() => handleViewChange(item.id)}
            className={`flex flex-col items-center p-5 rounded-[40px] transition-all transform active:scale-75 ${
              currentView === item.id ? 
                (isCrisis || isHumanitarian ? 'text-white bg-white/20 shadow-inner' : 
                 isOffline ? 'text-white bg-slate-700 shadow-xl border border-white/10' :
                 'text-blue-600 bg-blue-50 shadow-xl shadow-blue-100/50') : 
                (isCrisis || isHumanitarian || isOffline ? 'text-white/40' : 'text-gray-300')
            }`}
          >
            <item.icon size={52} strokeWidth={currentView === item.id ? 3 : 2} />
            <span className={`text-[12px] mt-3 font-black uppercase tracking-[0.3em] ${isOffline ? 'text-xs' : ''}`}>{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Privacy Badge */}
      <div className="absolute top-0 left-0 w-full flex justify-center pointer-events-none z-[70]">
         <span className={`text-[10px] font-black tracking-widest px-8 py-2 rounded-b-3xl shadow-2xl uppercase border-x border-b transition-colors duration-500 ${
           isCrisis || isHumanitarian ? 'bg-white/10 text-white/50 border-white/10' : 
           isOffline ? 'bg-slate-900 text-white/40 border-slate-800' :
           'bg-blue-600 text-white border-blue-700'
         }`}>{t.privacyNotice}</span>
      </div>
    </div>
  );
};

export default Layout;
