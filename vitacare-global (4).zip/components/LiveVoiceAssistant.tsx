
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { Mic, MicOff, X, Sparkles, Volume2, MessageCircle } from 'lucide-react';
import { LiveChatMessage } from '../types';
import { audioService } from '../services/audioService';

interface LiveVoiceAssistantProps {
  onClose: () => void;
  systemInstruction: string;
  voiceName?: string;
}

export const LiveVoiceAssistant: React.FC<LiveVoiceAssistantProps> = ({ 
  onClose, 
  systemInstruction, 
  voiceName = 'Kore' 
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [history, setHistory] = useState<LiveChatMessage[]>([]);
  const [currentModelText, setCurrentModelText] = useState('');
  const [currentUserText, setCurrentUserText] = useState('');

  const sessionRef = useRef<any>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Helper functions for base64 encoding/decoding
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const createBlob = (data: Float32Array): Blob => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  const stopLiveSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (inputAudioCtxRef.current) {
      inputAudioCtxRef.current.close();
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      outputAudioCtxRef.current.close();
      outputAudioCtxRef.current = null;
    }
    setIsConnected(false);
    setIsRecording(false);
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
  };

  const startLiveSession = async () => {
    try {
      audioService.playAction();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      inputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsRecording(true);
            const source = inputAudioCtxRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioCtxRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Audio
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outputAudioCtxRef.current) {
              const ctx = outputAudioCtxRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }

            // Handle Interruptions
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            // Handle Transcription
            if (message.serverContent?.inputTranscription) {
              setCurrentUserText(prev => prev + message.serverContent!.inputTranscription!.text);
            }
            if (message.serverContent?.outputTranscription) {
              setCurrentModelText(prev => prev + message.serverContent!.outputTranscription!.text);
            }

            // Fix: Explicitly cast 'sender' properties as const to ensure the type matches the LiveChatMessage union type definition ('user' | 'model').
            if (message.serverContent?.turnComplete) {
              setHistory(prev => [
                ...prev,
                { text: currentUserText, sender: 'user' as const, timestamp: new Date() },
                { text: currentModelText, sender: 'model' as const, timestamp: new Date() }
              ].filter(m => m.text.trim() !== ''));
              setCurrentUserText('');
              setCurrentModelText('');
            }
          },
          onerror: (e) => console.error('Live API Error:', e),
          onclose: () => stopLiveSession()
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName } }
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start Live session:', err);
      stopLiveSession();
    }
  };

  useEffect(() => {
    startLiveSession();
    return () => stopLiveSession();
  }, [voiceName]);

  return (
    <div className="fixed inset-0 z-[300] bg-blue-900/95 backdrop-blur-2xl flex flex-col p-8 text-white animate-fadeIn">
      <header className="flex justify-between items-center mb-10">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-3xl flex items-center justify-center border border-white/20">
            <Sparkles className="text-blue-200 animate-pulse" size={32} />
          </div>
          <div>
            <h2 className="text-4xl font-black tracking-tighter uppercase leading-none">Voz de Luiza</h2>
            <p className="text-sm font-bold text-blue-300 uppercase tracking-widest mt-1">
              {isConnected ? 'Conectado em tempo real' : 'Conectando...'}
            </p>
          </div>
        </div>
        <button 
          onClick={() => { audioService.playTick(); onClose(); }}
          className="p-4 bg-white/10 rounded-full hover:bg-white/20 active:scale-90 transition-all"
        >
          <X size={32} />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto space-y-6 mb-8 px-4 flex flex-col-reverse">
        {/* Real-time streaming text */}
        {currentModelText && (
          <div className="bg-white/10 p-6 rounded-[35px] border-l-8 border-blue-400 self-start max-w-[85%] animate-fadeIn">
            <p className="text-2xl font-bold leading-snug">{currentModelText}</p>
          </div>
        )}
        {currentUserText && (
          <div className="bg-blue-600/30 p-6 rounded-[35px] border-r-8 border-white/30 self-end max-w-[85%] animate-fadeIn">
            <p className="text-2xl font-bold leading-snug italic text-white/80">{currentUserText}</p>
          </div>
        )}

        {/* Conversation History */}
        {history.slice().reverse().map((msg, i) => (
          <div 
            key={i} 
            className={`p-6 rounded-[35px] max-w-[85%] ${
              msg.sender === 'model' 
                ? 'bg-white/5 border border-white/10 self-start' 
                : 'bg-blue-500/20 border border-blue-400/20 self-end'
            }`}
          >
            <p className={`text-xl font-bold leading-snug ${msg.sender === 'user' ? 'italic opacity-70' : ''}`}>
              {msg.text}
            </p>
          </div>
        ))}

        {!history.length && !currentModelText && !currentUserText && isConnected && (
          <div className="flex flex-col items-center justify-center py-20 text-center opacity-40">
             <MessageCircle size={80} className="mb-4" />
             <p className="text-3xl font-black uppercase tracking-tighter">Luiza está ouvindo...</p>
             <p className="text-xl font-bold mt-2">Diga o que você precisa ou como se sente.</p>
          </div>
        )}
      </div>

      <footer className="flex flex-col items-center gap-8">
        <div className="flex items-center justify-center gap-12 relative">
          {/* Pulsing rings for visual feedback */}
          {isRecording && (
            <>
              <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping opacity-20" style={{ animationDuration: '2s' }}></div>
              <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping opacity-10" style={{ animationDuration: '3s', animationDelay: '0.5s' }}></div>
            </>
          )}
          
          <button 
            className={`w-32 h-32 rounded-full flex items-center justify-center transition-all shadow-4xl relative z-10 ${
              isRecording ? 'bg-white text-blue-600 scale-110' : 'bg-white/10 text-white'
            }`}
          >
            {isRecording ? <Volume2 size={56} /> : <MicOff size={56} />}
          </button>
        </div>

        <button 
          onClick={() => { audioService.playEmergency(); onClose(); }}
          className="w-full bg-red-600 text-white py-10 rounded-[45px] font-black text-3xl shadow-3xl flex items-center justify-center gap-4 border-b-[12px] border-red-900 active:translate-y-2 active:border-b-0 transition-all"
        >
          ENCERRAR CONVERSA
        </button>
      </footer>
    </div>
  );
};

export default LiveVoiceAssistant;
