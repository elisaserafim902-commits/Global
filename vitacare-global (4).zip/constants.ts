
import { RiskLevel, ComplexityLevel, Alert, ProviderType, ProviderStatus, ProviderProfile, SystemMode, DisasterType } from './types';

export const MANIFESTO = {
  'pt-BR': "VitaCare: Tecnologia com alma para proteger quem você ama.",
  'en-US': "VitaCare: Technology with soul to protect those you love.",
  'de-DE': "VitaCare: Technologie mit Seele, um Ihre Lieben zu schützen.",
  'ja-JP': "VitaCare：大切な人を守るために、魂のこもったテクノロジーを。"
};

export const MEDICAL_DISCLAIMER = "Este aplicativo não substitui serviços médicos, autoridades ou serviços de emergência (190/192/193).";

export const COLORS = {
  primary: '#2563EB',
  secondary: '#7C3AED',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  neutral: '#F9FAFB',
  crisis: '#DC2626',
  offline: '#4B5563',
  text: '#111827',
  white: '#FFFFFF',
  family: '#7C3AED'
};

// Added MOCK_TERRITORY for PublicAgentPanel
export const MOCK_TERRITORY = [
  { id: 'VITA-001', name: 'Dona Maria', risk: RiskLevel.MEDIUM },
  { id: 'VITA-002', name: 'Sr. João', risk: RiskLevel.HIGH },
  { id: 'VITA-003', name: 'Dona Alice', risk: RiskLevel.LOW },
  { id: 'VITA-004', name: 'Sr. Benedito', risk: RiskLevel.CRITICAL },
];

export const DISASTER_META = {
  [DisasterType.TSUNAMI]: { 
    label: 'Tsunami', 
    color: 'bg-blue-600', 
    icon: 'Waves',
    guideScript: "Atenção. Estou aqui para te orientar com calma. Há um alerta oficial para ondas fortes. Afaste-se do litoral agora. Vá para um local mais alto. Leve documentos e remédios. Siga a defesa civil."
  },
  [DisasterType.EARTHQUAKE]: { 
    label: 'Terremoto', 
    color: 'bg-orange-600', 
    icon: 'Mountain',
    guideScript: "Atenção. Alerta oficial de possível tremor. Afaste-se das janelas. Proteja a cabeça. Procure abrigo seguro. Siga as autoridades."
  },
  [DisasterType.CYCLONE]: { 
    label: 'Ciclone', 
    color: 'bg-indigo-600', 
    icon: 'Wind',
    guideScript: "Orientação importante. Há previsão oficial de tempestade forte. Fique em local seguro. Feche portas e janelas. Evite sair. Aviso se houver mudanças."
  },
  [DisasterType.FLOOD]: { 
    label: 'Enchente', 
    color: 'bg-blue-400', 
    icon: 'Droplets',
    guideScript: "Atenção. Há risco de inundação na sua área. Procure locais elevados. Evite contato com a água das enchentes. Desligue a energia se necessário."
  },
  [DisasterType.WILDFIRE]: { 
    label: 'Incêndio', 
    color: 'bg-red-600', 
    icon: 'Flame',
    guideScript: "Aviso de segurança. Fogo detectado nas proximidades. Feche todas as aberturas da casa. Siga as rotas de evacuação oficiais imediatamente."
  },
  [DisasterType.VOLCANO]: { 
    label: 'Vulcão', 
    color: 'bg-red-800', 
    icon: 'LandPlot',
    guideScript: "Alerta vulcânico. Proteja as vias respiratórias. Evite áreas baixas onde gases podem se acumular. Siga as instruções de evacuação."
  },
  [DisasterType.BLIZZARD]: { 
    label: 'Nevasca', 
    color: 'bg-blue-100', 
    icon: 'Snowflake',
    guideScript: "Alerta de frio intenso e neve. Permaneça em local aquecido. Evite viajar. Tenha suprimentos de emergência à mão."
  },
  [DisasterType.HEATWAVE]: { 
    label: 'Onda de Calor', 
    color: 'bg-orange-400', 
    icon: 'Sun',
    guideScript: "Alerta de calor extremo. Mantenha-se hidratado. Procure ambientes frescos ou com sombra. Evite atividades físicas intensas ao ar livre."
  },
  [DisasterType.EPIDEMIC]: { 
    label: 'Crise Sanitária', 
    color: 'bg-emerald-600', 
    icon: 'Biohazard',
    guideScript: "Orientação de saúde. Siga os protocolos de higiene. Mantenha o distanciamento recomendado. Acompanhe os informativos oficiais de saúde."
  },
  [DisasterType.HUMANITARIAN_ISOLATION]: { 
    label: 'Apoio Humanitário', 
    color: 'bg-[#0f172a]', 
    icon: 'Heart',
    guideScript: "Você não está sozinho. A rede de apoio humanitário está ativa para garantir sua segurança e suprimentos básicos."
  }
};

export const UI_STRINGS = {
  'pt-BR': {
    appName: 'VitaCare',
    greeting: 'Bom dia, Maria',
    needHelp: 'Socorro imediato',
    askSomething: 'Pedir algo à Luiza',
    privacyNotice: 'Privacidade Ética Garantida',
    crisisTitle: 'ALERTA DE SEGURANÇA',
    crisisDesc: 'Luiza detectou uma situação importante e já avisou sua família.',
    offlineTitle: 'MODO OFFLINE ATIVO',
    offlineDesc: 'Rede de rádio emergencial conectada.',
    twinTitle: 'Saúde Digital',
    preventionPanel: 'REDE DE PROTEÇÃO',
    statusSafe: 'Ambiente Seguro',
    statusRisk: 'Atenção Necessária',
    manifesto: MANIFESTO['pt-BR'],
    consentRequest: 'Autorização de Cuidado',
    consentExplain: 'Para sua segurança, Luiza monitora seu bem-estar e compartilha com sua família.',
    legalPrivacy: 'Política de Dados',
    legalTerms: 'Termos de Cuidado',
    legalCompliance: 'Conformidade Ética Ativa',
    sosProtocol: 'Protocolo Vita-SOS',
    disclaimer: MEDICAL_DISCLAIMER
  },
  'en-US': {
    appName: 'VitaCare',
    greeting: 'Good morning, Maria',
    needHelp: 'Emergency Help',
    askSomething: 'Ask Luiza',
    privacyNotice: 'Ethical Privacy Guaranteed',
    crisisTitle: 'SAFETY ALERT',
    crisisDesc: 'Luiza detected a situation and notified your family.',
    offlineTitle: 'OFFLINE MODE ACTIVE',
    offlineDesc: 'Emergency radio network connected.',
    twinTitle: 'Digital Health',
    preventionPanel: 'PROTECTION NETWORK',
    statusSafe: 'Safe Environment',
    statusRisk: 'Attention Needed',
    manifesto: MANIFESTO['en-US'],
    consentRequest: 'Care Authorization',
    consentExplain: 'For your safety, Luiza monitors your well-being and shares it with your family.',
    legalPrivacy: 'Data Policy',
    legalTerms: 'Care Terms',
    legalCompliance: 'Ethical Compliance Active',
    sosProtocol: 'Vita-SOS Protocol',
    disclaimer: "This app does not replace medical services, authorities, or emergency services."
  }
};

export const PRIVACY_POLICY_URL = "https://vitacare.ai/privacy";
export const TERMS_URL = "https://vitacare.ai/terms";

export const MOCK_ELDERLY_USER = {
  name: "Dona Maria",
  id: "VITA-PRO-001",
  phone: "+55 11 98877-6655",
  emergencyContact: "José (Filho)",
  country: "Brasil",
  language: "pt-BR",
  complexity: ComplexityLevel.BALANCED
};

export const INITIAL_ALERTS: Alert[] = [
  {
    id: 'alert-init-1',
    title: 'Monitoramento Ativo',
    message: 'Luiza está cuidando de você hoje. Sua família está conectada.',
    type: 'success',
    timestamp: new Date(),
    isPreventive: true
  }
];

export const MOCK_PROVIDER: ProviderProfile = {
  id: 'PRO-99',
  name: 'Dra. Ana Paula',
  type: ProviderType.HEALTH,
  status: ProviderStatus.CERTIFIED,
  specialties: ['Geriatria', 'Cuidados Paliativos'],
  ethicalScore: 4.99,
  location: { lat: -23.5505, lng: -46.6333, address: 'Pinheiros, SP' },
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ana'
};
