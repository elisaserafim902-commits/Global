
/**
 * VitaCare Audio Feedback Service
 * Uses Web Audio API for procedural, lightweight, and offline-ready sound effects.
 */

class AudioService {
  private ctx: AudioContext | null = null;

  private initContext() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private playTone(freq: number, type: OscillatorType, duration: number, volume: number = 0.1) {
    this.initContext();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    
    gain.gain.setValueAtTime(volume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  /** Subtle tick for general navigation */
  public playTick() {
    this.playTone(880, 'sine', 0.05, 0.05);
  }

  /** Slightly warmer sound for main actions */
  public playAction() {
    this.playTone(660, 'sine', 0.1, 0.08);
  }

  /** Success chime for completed tasks */
  public playSuccess() {
    this.initContext();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    this.playTone(523.25, 'sine', 0.2, 0.05);
    setTimeout(() => this.playTone(659.25, 'sine', 0.3, 0.05), 100);
  }

  /** Gentle alert for notifications */
  public playNotification() {
    this.playTone(440, 'triangle', 0.2, 0.05);
  }

  /** Distinctive but non-alarmist emergency pulse */
  public playEmergency() {
    this.playTone(220, 'sine', 0.5, 0.1);
  }
}

export const audioService = new AudioService();
