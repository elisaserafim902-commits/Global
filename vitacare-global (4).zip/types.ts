
export enum UserRole {
  ELDERLY = 'ELDERLY',
  FAMILY = 'FAMILY',
  PROVIDER = 'PROVIDER',
  PUBLIC_AGENT = 'PUBLIC_AGENT',
  PUBLIC_MANAGER = 'PUBLIC_MANAGER'
}

export enum ComplexityLevel {
  MINIMAL = 'MINIMAL',
  BALANCED = 'BALANCED',
  ADVANCED = 'ADVANCED'
}

export enum SystemMode {
  NORMAL = 'NORMAL',
  CRISIS = 'CRISIS',
  OFFLINE = 'OFFLINE',
  HUMANITARIAN = 'HUMANITARIAN' 
}

export enum DisasterType {
  TSUNAMI = 'TSUNAMI',
  EARTHQUAKE = 'EARTHQUAKE',
  CYCLONE = 'CYCLONE',
  FLOOD = 'FLOOD',
  WILDFIRE = 'WILDFIRE',
  VOLCANO = 'VOLCANO',
  BLIZZARD = 'BLIZZARD',
  HEATWAVE = 'HEATWAVE',
  EPIDEMIC = 'EPIDEMIC',
  HUMANITARIAN_ISOLATION = 'HUMANITARIAN_ISOLATION'
}

export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export interface LiveChatMessage {
  text: string;
  sender: 'user' | 'model';
  timestamp: Date;
}

export enum ProviderType {
  HEALTH = 'HEALTH',
  CARE = 'CARE',
  SUPPORT = 'SUPPORT',
  VOLUNTEER = 'VOLUNTEER'
}

export enum ProviderStatus {
  CERTIFIED = 'CERTIFIED',
  VALIDATED = 'VALIDATED',
  PENDING = 'PENDING'
}

export interface EmergencyResponse {
  title: string;
  source: string;
  what_is_happening: string;
  what_to_do_now: string[];
  what_to_avoid: string[];
  important_note: string;
  risk_level: 'low' | 'moderate' | 'high' | 'extreme';
  notify_family: boolean;
  notify_authorities: boolean;
}

export enum ServiceCategory {
  MARKET = 'MARKET',
  PHARMACY = 'PHARMACY',
  COMPANIONSHIP = 'COMPANIONSHIP',
  PROFESSIONAL_CARE = 'PROFESSIONAL_CARE',
  HELP = 'HELP'
}

export enum OrderStatus {
  RECEIVED = 'RECEIVED',
  MATCHING = 'MATCHING',
  PREPARING = 'PREPARING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  DELIVERED = 'DELIVERED'
}

export interface ProviderProfile {
  id: string;
  name: string;
  type: ProviderType;
  status: ProviderStatus;
  specialties: string[];
  ethicalScore: number;
  location: { lat: number; lng: number; address: string };
  avatar: string;
}

export interface Order {
  id: string;
  category: ServiceCategory;
  description: string;
  status: OrderStatus;
  timestamp: Date;
  patientName: string;
  familyApproved: boolean;
  urgency: 'routine' | 'urgent' | 'emotional';
  matchedProvider?: {
    name: string;
    type: string;
    rating: number;
    avatar: string;
  };
}

export interface DisasterEvent {
  type: DisasterType;
  severity: 'MODERATE' | 'SEVERE' | 'EXTREME';
  location: string;
  timestamp: Date;
  guidance: string[];
  humanitarian_context?: string;
}

export interface CareScores {
  trust: number;
  vulnerability: number;
  stability: number;
  socialEngagement: number;
}

export interface CareDigitalTwin {
  lastKnownMood: string;
  behavioralPattern: string;
  vitalThresholds: { heartRate: string; sleep: string };
  culturalPreferences: string[];
  educationLevel: number;
}

export interface HumanitarianResponse {
  crisis_level: 'moderate' | 'high' | 'critical';
  recommended_actions: string[];
  communications_sent: string[];
  network_activated: 'family' | 'community' | 'authorities' | 'none';
  ethical_justification: string;
  human_presence_mode: boolean; 
  daily_routine: string[]; 
  next_check_in_hours: number;
}

export interface AIActionResponse {
  detected_need: string;
  urgency_level: 'low' | 'medium' | 'high' | 'critical';
  recommended_action: string;
  service_type: 'family' | 'provider_online' | 'provider_presential' | 'public_support';
  notify_family: boolean;
  notify_provider: boolean;
  explanation: string;
}

export interface ProviderMatchResponse {
  provider_type: string;
  service_mode: 'online' | 'presential';
  priority_criteria: string[];
  provider_recommendation_reason: string;
}

export interface SilentRiskResponse {
  risk_detected: boolean;
  risk_type: string;
  urgency_level: 'low' | 'medium' | 'high';
  recommended_follow_up: string;
  notify_family: boolean;
}

export interface LocalizationConfig {
  language: string;
  tone_style: string;
  interface_complexity: 'low' | 'medium' | 'high';
  communication_preference: 'text' | 'voice' | 'mixed';
}

export interface Alert {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'danger';
  timestamp: Date;
  isPreventive?: boolean;
}

export interface UserContext {
  language: 'pt-BR' | 'en-US' | 'es-ES' | 'ja-JP' | 'de-DE';
  country: string;
  complexity: ComplexityLevel;
  lastActivity: Date;
  mood?: 'happy' | 'neutral' | 'sad' | 'anxious';
  culturalTheme?: 'WESTERN' | 'EASTERN' | 'LATIN' | 'PRIVACY_FOCUSED';
  mode: SystemMode;
  twin: CareDigitalTwin;
  scores: CareScores;
  voiceName?: string;
  speechSpeed?: 'slow' | 'normal' | 'fast';
}
